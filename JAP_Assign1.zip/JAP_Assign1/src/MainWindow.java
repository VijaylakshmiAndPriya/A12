
import javax.swing.*;

import java.awt.*;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

 

public class MainWindow extends JPanel {

	

    private boolean[][] cells;

    private int generations;

    private int rule;

    private boolean ruleSet = false;

 

    private JTextField ruleInput;

    private JButton setRuleButton;

   

 

    private static final int CELL_SIZE = 1;

    private static final int WIDTH = 900;

    private static final int HEIGHT = 530;

 

   // create a label

   

    JLabel label1 = new JLabel("Language");

	 JLabel label2 = new JLabel("Model: ");

  

    

    JPanel grayPanel_Bottom = new JPanel();

    

    public MainWindow () {

    	

    	

    			

        setPreferredSize(new Dimension(WIDTH, HEIGHT));

        generations = 600 / CELL_SIZE;

        cells = new boolean[generations][WIDTH / CELL_SIZE];

 

        ruleInput = new JTextField(10);

        setRuleButton = new JButton("Set");

        setRuleButton.addActionListener(new ActionListener() {

            @Override

            public void actionPerformed(ActionEvent e) {

                try {

                    rule = Integer.parseInt(ruleInput.getText(), 2);

                    if (rule >= 0 && rule <= 255) {

                        ruleSet = true;

                    

                        generateGenerations();

                        repaint();

                    } else {

                        JOptionPane.showMessageDialog(null, "Rule must be between 0 and 255.");

                    }

                } catch (NumberFormatException ex) {

                    JOptionPane.showMessageDialog(null, "Invalid binary input.");

                }

            }

        });

        

     

        

	    // Bottom Panel

	    grayPanel_Bottom.setBackground(Color.PINK);

	

        //Bottom JPanel for Language Text   		

    	grayPanel_Bottom.add(label1);    	

    	label1.setForeground(Color.BLUE);

    	

    	

    	

    	 // ComboBox in the bottom

    	

    	 String [] options = { "English" , "Tamil", "Gujarati"};

    	 JComboBox<String> comboBox = new JComboBox<>(options);

    	 comboBox.setPreferredSize(new Dimension(150, 30));

    	 grayPanel_Bottom.add(comboBox);

		 comboBox.setForeground(Color.BLUE);

    	

		 // Bottom JPanel for Model text

         grayPanel_Bottom.add(label2);

         label2.setForeground(Color.BLUE);

        

        

         //Bottom JPanel for text input field

         grayPanel_Bottom.add(ruleInput);

         ruleInput.setForeground(Color.BLUE);

        

         // set button

         grayPanel_Bottom.add(setRuleButton);        

         setRuleButton.setForeground(Color.BLUE);

        

 

         setLayout(new BorderLayout());

         add(grayPanel_Bottom, BorderLayout.SOUTH);

 

   

    }

 

    private void generateGenerations() {

        cells[0][cells[0].length / 2] = true;

 

        for (int y = 0; y < generations - 1; y++) {

            for (int x = 1; x < cells[0].length - 1; x++) {

                boolean left = cells[y][x - 1];

                boolean center = cells[y][x];

                boolean right = cells[y][x + 1];

                int ruleIndex = (left ? 4 : 0) + (center ? 2 : 0) + (right ? 1 : 0);

                cells[y + 1][x] = (rule & (1 << ruleIndex)) != 0;

            }

        }

    }

    

    

    @Override

    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        if (ruleSet) {

            for (int y = 0; y < generations; y++) {

                for (int x = 1; x < cells[0].length; x++) {

                    if (cells[y][x]) {

                        g.setColor(Color.BLACK);

                        g.fillRect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE);

                    }

                }

            }

        }

    }

 

   public void cellular () {

        SwingUtilities.invokeLater(() -> {

            JFrame frame = new JFrame("Cellular Automaton");

            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            

            

            // topPanel

            JPanel topPanel = new JPanel();

            topPanel.setPreferredSize(new Dimension(WIDTH, 110));

            topPanel.setBackground(Color.PINK);

            frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));           

            ImageIcon image = new ImageIcon ("ca.png");             

            JLabel label = new JLabel(image);             		   

   		    topPanel.add(label);   

   		    

   		// added the panel in the Top

            frame.add(topPanel);

            frame.setResizable(false);

            frame.add(new MainWindow());

            frame.pack();

            frame.setLocationRelativeTo(null);

            frame.setVisible(true);

        });

    }

}

 

 