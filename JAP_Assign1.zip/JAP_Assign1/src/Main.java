public class Main {

 

	public static void main(String[] args) {

		

		InitialWindow Initial = new InitialWindow ();

	}

 

}