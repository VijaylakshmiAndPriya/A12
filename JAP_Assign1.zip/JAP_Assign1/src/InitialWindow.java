import javax.swing.*;

import java.awt.*;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

 

public class InitialWindow extends JFrame implements ActionListener {

 

	

	JFrame frame = new JFrame();

	JButton setRuleButton = new JButton("OK");

	JButton button1 = new JButton("Cancel");

	JButton button2 = new JButton("Help");

	JComboBox comboBox;

	

	

	InitialWindow (){

		

		

         ImageIcon image = new ImageIcon ("CSmin.png");    

		 JLabel label = new JLabel(); // create a label

		 label.setIcon(image);

		

	

		// OK Button

		

		 setRuleButton.setFocusable(false);

		 setRuleButton.addActionListener(this);	

		 setRuleButton.setFont(new Font("Comic Sans", Font.BOLD,15));

		 setRuleButton.setForeground(Color.BLUE);

	

		 // Cancel setRuleButton

		

			

		 button1.addActionListener(this);		

		 button1.setFont(new Font("Comic Sans", Font.BOLD,15));

		 button1.setForeground(Color.BLUE);

		

		 // Help Button

		

		

		 button2.addActionListener(this);	

		 button2.setFont(new Font("Comic Sans", Font.BOLD,15));

		 button2.setForeground(Color.BLUE);

		

		

		 // Combo box with options of games

		

		 String [] game = { "[A12] CA - Cellular Automata" , "[A22] GL - Game of Life", "[A32] TM - Turing Machine Server", "[A32] TM Client"};		

		 comboBox = new JComboBox<>(game);		

		 comboBox.setPreferredSize(new Dimension(250, 150));

		 comboBox.setForeground(Color.BLUE);

		

		

		 setLayout(new BorderLayout());

 

	        JPanel bottomPanel = new JPanel();

	        bottomPanel.add(setRuleButton);

	        bottomPanel.add(button1);

	        bottomPanel.add(button2);

 

	        JPanel rightPanel = new JPanel(new BorderLayout());

	        rightPanel.add(comboBox, BorderLayout.NORTH);

 

	        add(label, BorderLayout.WEST);

	        add(bottomPanel, BorderLayout.SOUTH);

	        add(rightPanel, BorderLayout.EAST);

 

	        setTitle("[JAP - Computer Science]");

	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	        setSize(400, 200);

	        setResizable(false);

	        setVisible(true);

		

	}

	

	/* actionPerformed that Action event for when click OK, cancel, and Help button.

	 * when select cellular automata and click Ok button, open new window for cellular automata

	 * when select remaining options and click ok button, it show information message

	 * when click Cancel button, it dispose the frame

	 * when click Help button, it show information message.

	 *

	 */

 

	@Override

	public void actionPerformed(ActionEvent e) {

		if (e.getSource()== setRuleButton) {

			

			if (comboBox.getSelectedItem() == "[A12] CA - Cellular Automata") {

				dispose();

				MainWindow myWindow = new MainWindow ();

				myWindow.cellular();

            }else if (comboBox.getSelectedItem().toString() == "[A22] GL - Game of Life") {

	                JOptionPane.showMessageDialog(null,  "Still in development stage.", "Input Error", JOptionPane.ERROR_MESSAGE);

	                

	                   

        	}else if (comboBox.getSelectedItem().toString()  == "[A32] TM - Turing Machine Server") {

            JOptionPane.showMessageDialog(null,  "Still in development stage.", "Input Error", JOptionPane.ERROR_MESSAGE);

            

        	

        	}else if (comboBox.getSelectedItem().toString()  == "[A32] TM - Turing Machine Server") {

                JOptionPane.showMessageDialog(null,  "Still in development stage.", "Input Error", JOptionPane.ERROR_MESSAGE);

                

        	}else if (comboBox.getSelectedItem().toString()  == "[A32] TM Client") {

                JOptionPane.showMessageDialog(null,  "Still in development stage.", "Input Error", JOptionPane.ERROR_MESSAGE);

                

        	}

		

		}else if (e.getSource()== button1) {

			dispose();

		}else if (e.getSource()== button2) {

			JOptionPane.showMessageDialog(null,  "There are four options, but the only one game implement. So, please select A12 - Cellular Automata and click OK. ", "Help", JOptionPane.ERROR_MESSAGE);

		}

	}

}

 